

def hours():
    print("open 9-5 daily")

